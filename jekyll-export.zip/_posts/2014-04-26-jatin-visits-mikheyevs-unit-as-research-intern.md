---
title: 'Jatin visits Mikheyev&#8217;s unit as Research Intern'
author: Jatin Arora
layout: post
permalink: /?p=1102
post_slider_check_key:
  - 0
layout_key:
  - 
post_slider_key:
  - 
categories:
  - Lab news
---
<p style="text-align: left">
  I am Jatin Arora. I came to know about Prof. Alexander Mikheyev and his Ecology and Evolution unit at OIST in October, 2013. I was <a href="http://ecoevo.unit.oist.jp/lab/wp-content/uploads/2014/04/blurb.jpg" class="grouped_elements" rel="tc-fancybox-group1102"><img class="alignright  wp-image-1111" alt="jatin arora" src="http://ecoevo.unit.oist.jp/lab/wp-content/uploads/2014/04/blurb.jpg" width="300" height="353" /></a>intrigued about the potential offered by using non-model systems, e.g. the species of honey bees, ants, snakes etc. to understand how organisms interact with their environment. In debut, I worked at distance with him on topic of Resilience to diseases in feral honey bee genome in third semester of my master studies at University Pierre and Marie Curie, Paris. Later, I joined the laboratory as research intern to do my master thesis. In present, I am working on the Introgressive hybridization of African genes into population of feral European bees. During my stay here, I hope to work in other areas as well, as the research in the laboratory is being done on a range of topics. The laboratory has cutting edge infrastructure. It is equipped with latest sequencing facilities. The experimental and analysis works are done in parallel which facilitates the access to data and validation of hypothesis. Along with working on computational analysis, I participate in wet lab experiments as well, which complements my learning. There are six nationalities in the laboratory which allows learning different cultures under one roof and makes the work environment more exciting.
</p>

&nbsp;