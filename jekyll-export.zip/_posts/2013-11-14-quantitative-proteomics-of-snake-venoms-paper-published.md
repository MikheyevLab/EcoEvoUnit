---
title: Quantitative proteomics of snake venoms paper published
author: sasha
layout: post
permalink: /?p=1030
layout_key:
  - 
post_slider_check_key:
  - 0
categories:
  - Lab news
---
Thanks to the hard work of Steve, and the help of Alex and Roy in mass spec, we were able to quantitatively measure protein concentrations in the venoms of two local snake species. The paper just went online in [BMC Genomics][1].

 [1]: http://www.biomedcentral.com/1471-2164/14/790/abstract