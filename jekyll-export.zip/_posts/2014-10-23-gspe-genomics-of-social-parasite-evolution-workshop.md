---
title: 'GSPE: Genomics of Social Parasite Evolution Workshop'
author: sasha
layout: post
permalink: /?p=1176
layout_key:
  - 
post_slider_check_key:
  - 0
categories:
  - Lab news
---
We were happy to host our excellent US and European-based collaborators to jointly work on the evolution of social parasite genomes. In the few days of the workshop we made major progress, finally bringing the project over the hill and hopefully en route to eventual publication.

<a href="http://ecoevo.unit.oist.jp/lab/wp-content/uploads/2014/10/GSPE.jpg" class="grouped_elements" rel="tc-fancybox-group1176"><img src="http://ecoevo.unit.oist.jp/lab/wp-content/uploads/2014/10/GSPE.jpg" alt="GSPE" width="800" height="600" class="alignnone size-full wp-image-1177" /></a> Participants (as ordered in photo): Ti Eriksson (Arizona State University), Sara Helms Cahan (University of Vermont), Karsten Kemena (Muenster University), Andy Suarez (University of Illinois), Sasha Mikheyev (OIST) Misato Miyakawa (OIST), Juergen Gadau (ASU), Chris Smith (Earlham College), Martin Helmkampf (ASU)