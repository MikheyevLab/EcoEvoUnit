---
title: Shikha scores at the top of her class
author: sasha
layout: post
permalink: /?p=1150
layout_key:
  - 
post_slider_check_key:
  - 0
categories:
  - Lab news
---
Shikha just received her grades, scoring at the top of her class, and completing her thesis. Congratulations!