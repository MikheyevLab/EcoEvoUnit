---
title: Habu study press release by OIST!
author: sasha
layout: post
permalink: /?p=1063
layout_key:
  - 
post_slider_check_key:
  - 0
categories:
  - Uncategorized
---
If you want to read the take home message of the habu study without wading through the paper, the kind folks at OIST&#8217;s Communications have drawn up a handy press release. You can find it [][1].

 [1]: http://www.oist.jp/news-center/news/2013/12/9/biting-snake-venom-mysteries "here"