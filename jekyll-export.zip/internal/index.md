---
title: Internal
author: sasha
layout: page
layout_key:
  - 
post_slider_check_key:
  - 0
---
## Lab meeting

  * [Lab meeting signup & schedule][1]

&nbsp;

## Code blog

[- How to use Pelican. Static site Generator.][2]

 [1]: https://docs.google.com/spreadsheet/ccc?key=0Ahko1c4b-r_7dDBNOGxSWDZaRlcxNUh1YlRKX0p1aFE#gid=0
 [2]: http://ecoevo.unit.oist.jp/lab/wp-content/uploads/2014/01/howTo_pelican.pdf